using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using AutoAnalysisTaskFeeder.Models;
using AutoAnalysisTaskFeeder.Services;
using AutoAnalysisTaskFeeder.Utilities;
using TaskStatusEnum = AutoAnalysisTaskFeeder.Models.TaskStatus;

namespace AutoAnalysisTaskFeeder.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IFolderScanService _folderScanService;
        private readonly IIniService _iniService;
        private readonly IProcessRunner _processRunner;
        private readonly ILogService _logService;
        private readonly SemaphoreSlim _executionLock = new(1, 1);

        // Properties
        private ObservableCollection<TaskItem> _tasks = new();
        public ObservableCollection<TaskItem> Tasks
        {
            get => _tasks;
            set => SetProperty(ref _tasks, value);
        }

        private string _analysisTaskPath = "";
        public string AnalysisTaskPath
        {
            get => _analysisTaskPath;
            set => SetProperty(ref _analysisTaskPath, value);
        }

        private string _pcrAnalysisExePath = "";
        public string PcrAnalysisExePath
        {
            get => _pcrAnalysisExePath;
            set => SetProperty(ref _pcrAnalysisExePath, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set => SetProperty(ref _isBusy, value);
        }

        private string _statusMessage = "Ready";
        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        private double _progressValue;
        public double ProgressValue
        {
            get => _progressValue;
            set => SetProperty(ref _progressValue, value);
        }

        private int _totalCount;
        public int TotalCount
        {
            get => _totalCount;
            set => SetProperty(ref _totalCount, value);
        }

        private int _processedCount;
        public int ProcessedCount
        {
            get => _processedCount;
            set => SetProperty(ref _processedCount, value);
        }

        private string _logText = "";
        public string LogText
        {
            get => _logText;
            set => SetProperty(ref _logText, value);
        }

        // Commands
        public ICommand SelectFolderCommand { get; }
        public ICommand GenerateIniCommand { get; }
        public ICommand StartAnalysisCommand { get; }
        public ICommand SelectAnalysisTaskPathCommand { get; }
        public ICommand SelectPcrAnalysisPathCommand { get; }

        public MainViewModel(
            IFolderScanService folderScanService,
            IIniService iniService,
            IProcessRunner processRunner,
            ILogService logService)
        {
            _folderScanService = folderScanService ?? throw new ArgumentNullException(nameof(folderScanService));
            _iniService = iniService ?? throw new ArgumentNullException(nameof(iniService));
            _processRunner = processRunner ?? throw new ArgumentNullException(nameof(processRunner));
            _logService = logService ?? throw new ArgumentNullException(nameof(logService));

            // �q�\��x�ܧ�ƥ�
            _logService.LogChanged += OnLogChanged;

            // Setup commands
            SelectFolderCommand = new AsyncRelayCommand(OnSelectFolder);
            GenerateIniCommand = new AsyncRelayCommand(OnGenerateIni);
            StartAnalysisCommand = new AsyncRelayCommand(OnStartAnalysis);
            SelectAnalysisTaskPathCommand = new RelayCommand(OnSelectAnalysisTaskPath);
            SelectPcrAnalysisPathCommand = new RelayCommand(OnSelectPcrAnalysisPath);

            // ��l�Ƥ�x
            _logService.LogInfo("���ε{���w�Ұ�");
        }

        private void OnLogChanged(string newLog)
        {
            // ��s UI �W�� LogText
            System.Windows.Application.Current?.Dispatcher.InvokeAsync(() =>
            {
                LogText = newLog;
            });
        }

        private async Task OnSelectFolder()
        {
            await _executionLock.WaitAsync();
            try
            {
                IsBusy = true;
                StatusMessage = "���b���y��Ƨ�...";
                _logService.LogInfo("�}�l��ܸ�Ƨ�");

                // �ϥ� FolderBrowserDialog ��ܸ�Ƨ�
                using var dialog = new System.Windows.Forms.FolderBrowserDialog
                {
                    Description = "�п�ܹ����Ƨ�",
                    ShowNewFolderButton = false
                };

                var result = dialog.ShowDialog();
                if (result != System.Windows.Forms.DialogResult.OK || string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    StatusMessage = "�w�������";
                    return;
                }

                var folderPath = dialog.SelectedPath;
                _logService.LogInfo($"�w��ܸ�Ƨ�: {folderPath}");

                Tasks.Clear();
                TotalCount = 0;
                ProcessedCount = 0;
                ProgressValue = 0;

                var scannedTasks = await _folderScanService.ScanFoldersAsync(new[] { folderPath });

                foreach (var task in scannedTasks)
                {
                    Tasks.Add(task);
                }

                TotalCount = Tasks.Count;
                StatusMessage = $"���y�����A��� {TotalCount} �ӥ���";
                _logService.LogInfo($"���y����: {TotalCount} �ӥ���");
            }
            catch (Exception ex)
            {
                StatusMessage = "���y����";
                _logService.LogError($"���y���~: {ex.Message}");
            }
            finally
            {
                IsBusy = false;
                _executionLock.Release();
            }
        }

        private async Task OnGenerateIni()
        {
            await _executionLock.WaitAsync();
            try
            {
                IsBusy = true;
                StatusMessage = "Generating INI files...";
                ProcessedCount = 0;

                var tasksToProcess = Tasks.Where(t => t.Status == TaskStatusEnum.Pending).ToList();

                foreach (var task in tasksToProcess)
                {
                    task.Status = TaskStatusEnum.Generating;

                    try
                    {
                        var iniContent = _iniService.GenerateIniContent(task);
                        var savePath = Path.Combine(AnalysisTaskPath, "New", "NewAnalysis.ini");

                        _iniService.WriteIniFile(savePath, iniContent);
                        task.Status = TaskStatusEnum.IniGenerated;
                        ProcessedCount++;
                        ProgressValue = (ProcessedCount * 100.0) / tasksToProcess.Count;
                    }
                    catch (Exception ex)
                    {
                        task.Status = TaskStatusEnum.Failed;
                        task.ErrorMessage = ex.Message;
                        _logService.LogError($"INI generation failed for {task.FolderName}: {ex.Message}");
                    }
                }

                StatusMessage = "INI generation complete";
            }
            finally
            {
                IsBusy = false;
                _executionLock.Release();
            }
        }

        private async Task OnStartAnalysis()
        {
            await _executionLock.WaitAsync();
            try
            {
                IsBusy = true;
                StatusMessage = "Starting analysis...";
                ProcessedCount = 0;

                var tasksToRun = Tasks.Where(t => t.Status == TaskStatusEnum.IniGenerated).ToList();

                foreach (var task in tasksToRun)
                {
                    try
                    {
                        task.Status = TaskStatusEnum.Running;

                        // Start process
                        var processId = _processRunner.StartProcess(PcrAnalysisExePath);
                        if (processId < 0)
                        {
                            task.Status = TaskStatusEnum.Failed;
                            task.ErrorMessage = "Failed to start process";
                            continue;
                        }

                        // Monitor completion
                        var completeDir = Path.Combine(AnalysisTaskPath, "Complete");
                        var completed = await _processRunner.MonitorCompletionAsync(
                            completeDir,
                            900); // 15 minutes timeout

                        if (completed)
                        {
                            task.Status = TaskStatusEnum.Completed;
                            ProcessedCount++;
                        }
                        else
                        {
                            task.Status = TaskStatusEnum.Failed;
                            task.ErrorMessage = "Process timeout";
                            _processRunner.KillProcess(processId);
                        }
                    }
                    catch (Exception ex)
                    {
                        task.Status = TaskStatusEnum.Failed;
                        task.ErrorMessage = ex.Message;
                        _logService.LogError($"Analysis failed for {task.FolderName}: {ex.Message}");
                    }

                    ProgressValue = (ProcessedCount * 100.0) / tasksToRun.Count;
                }

                StatusMessage = "Analysis complete";
            }
            finally
            {
                IsBusy = false;
                _executionLock.Release();
            }
        }

        private void OnSelectAnalysisTaskPath()
        {
            _logService.LogInfo("�}�l��� AnalysisTask ���|");

            using var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "�п�� AnalysisTask ��Ƨ�",
                ShowNewFolderButton = true
            };

            if (!string.IsNullOrEmpty(AnalysisTaskPath) && Directory.Exists(AnalysisTaskPath))
            {
                dialog.SelectedPath = AnalysisTaskPath;
            }

            var result = dialog.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                AnalysisTaskPath = dialog.SelectedPath;
                _logService.LogInfo($"�w�]�w AnalysisTask ���|: {AnalysisTaskPath}");
            }
            else
            {
                _logService.LogInfo("�w������� AnalysisTask ���|");
            }
        }

        private void OnSelectPcrAnalysisPath()
        {
            _logService.LogInfo("�}�l��� PCR ���R�{��");

            using var dialog = new System.Windows.Forms.OpenFileDialog
            {
                Title = "�п�� QKBqPCRAnalysis.exe",
                Filter = "������ (*.exe)|*.exe|�Ҧ��ɮ� (*.*)|*.*",
                CheckFileExists = true
            };

            if (!string.IsNullOrEmpty(PcrAnalysisExePath) && File.Exists(PcrAnalysisExePath))
            {
                dialog.InitialDirectory = Path.GetDirectoryName(PcrAnalysisExePath);
                dialog.FileName = Path.GetFileName(PcrAnalysisExePath);
            }

            var result = dialog.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                PcrAnalysisExePath = dialog.FileName;
                _logService.LogInfo($"�w�]�w PCR ���R�{�����|: {PcrAnalysisExePath}");
            }
            else
            {
                _logService.LogInfo("�w������� PCR ���R�{��");
            }
        }
    }
}
